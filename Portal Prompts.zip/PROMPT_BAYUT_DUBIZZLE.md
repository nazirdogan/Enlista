# Claude Code Prompt: Bayut & dubizzle Listing Format Compliance

## Context

You are building the listing output for ListingLaunch (https://listing-launch-uae.netlify.app/new), a bilingual property listing tool for UAE real estate agents. When an agent fills in the property form and clicks "Generate Listing", the output must be fully compliant with Bayut and dubizzle's listing requirements so the agent can paste it directly into Profolio (Bayut's listing management platform) with zero edits or rejections.

Bayut is the parent company of dubizzle — they share the same listing standards. One compliant output works for both portals.

---

## OUTPUT FORMAT

Generate a structured listing output with the following clearly labelled sections, ready for the agent to copy-paste field by field into Profolio:

---

### 1. PROPERTY TITLE (English)

**Rules:**
- Minimum 30 characters, maximum 50 characters (sweet spot: 40-50)
- Must be short, precise, and attention-grabbing
- Do NOT repeat information already captured in the listing fields (e.g. don't say "2 Bedroom Apartment in Dubai Marina" — the portal already shows beds, type, and location)
- Focus on the property's unique selling point or key differentiator
- No emojis, no special characters (💠❤️ etc.), no excessive capitalisation
- No agent name, agency name, phone numbers, or URLs in the title
- No pricing information in the title

**Good examples:**
- "Corner Unit with Full Marina & Golf Course Views"
- "Upgraded Kitchen | Vacant | High Floor"
- "Brand New | Private Garden | Backing Park"
- "Investor Deal | High ROI | Tenanted"

**Bad examples:**
- "2BR Apartment For Sale" (repeats listing fields)
- "AMAZING DEAL!!! MUST SEE!!!" (excessive caps/punctuation)
- "Call Ahmed 050XXXXXXX" (contact info)
- "Beautiful home" (too vague, under 30 chars)

---

### 2. PROPERTY TITLE (Arabic)

**Rules:**
- Same constraints as English (30-50 characters)
- Must be a natural Arabic translation/localisation — not a Google Translate output
- Right-to-left text, proper Arabic grammar
- Should convey the same selling point as the English title but adapted for Arabic-speaking audience
- Use common UAE real estate Arabic terminology

---

### 3. PROPERTY DESCRIPTION (English)

**Rules:**
- Minimum 750 characters, maximum 2,000 characters (target: 1,000-1,500 for optimal quality score)
- Minimum 300 characters required by Profolio, but 750+ needed for verification eligibility
- Must NOT conflict with the listing data fields (beds, baths, size, price, location) — if you say "3 bedrooms" in the description but the listing says 2, it will be rejected
- Must NOT include agent name, agency name, phone numbers, email addresses, or URLs
- Must NOT include pricing (price is a separate field)
- Must NOT include misleading information or claims that conflict with uploaded photos
- Include information that photos and data fields cannot express: lifestyle, neighbourhood context, nearby amenities, unique features, condition, views, natural light, layout flow
- Write in complete sentences, proper grammar, professional tone
- No ALL CAPS sections
- No HTML tags or special formatting characters
- Adapt tone based on the listing style selected (Professional / Luxury / Investment)

**Structure guide:**
1. Opening hook — the property's standout feature (1-2 sentences)
2. Interior walkthrough — layout, rooms, finishes, condition (2-3 sentences)
3. Building/community amenities (1-2 sentences)
4. Location context — what's nearby, commute, lifestyle (1-2 sentences)
5. Call-to-action or availability note (1 sentence)

**Style variations:**
- **Professional:** Clean, factual, broker-grade. Focus on specs, condition, value proposition. Avoid flowery language.
- **Luxury:** Aspirational, lifestyle-led. Use sensory language, emphasise prestige, exclusivity, design. Words like "bespoke", "curated", "unparalleled".
- **Investment:** ROI-focused, yield-driven. Mention rental potential, capital appreciation, tenant status, payment plans, handover dates if applicable.

---

### 4. PROPERTY DESCRIPTION (Arabic)

**Rules:**
- Same character limits as English (750-2,000 characters)
- Must be a professionally written Arabic description — not a word-for-word translation
- Adapt the tone and structure for Arabic-speaking property seekers
- Use standard Modern Standard Arabic with common UAE real estate terminology
- Right-to-left, proper grammar, no transliteration of English words where Arabic equivalents exist
- Common Arabic real estate terms to use:
  - شقة (apartment), فيلا (villa), تاون هاوس (townhouse), بنتهاوس (penthouse)
  - غرفة نوم (bedroom), حمام (bathroom), موقف سيارة (parking)
  - إطلالة بحرية (sea view), إطلالة على المارينا (marina view)
  - مفروشة (furnished), غير مفروشة (unfurnished)
  - جاهزة للسكن (ready to move in), على المخطط (off-plan)
  - عائد استثماري (ROI), دفعة أولى (down payment)

---

### 5. KEY FEATURES / AMENITIES

**Rules:**
- Select only amenities that genuinely apply to the property — irrelevant amenities are a rejection reason
- Use Bayut's predefined amenity categories. Do NOT invent custom amenity names.
- Map the features selected in ListingLaunch to these exact Bayut-accepted values:

**Accepted amenity values (use these exact terms):**
- Balcony, Built in Wardrobes, Central A/C, Covered Parking, Kitchen Appliances, Maid's Room, Pets Allowed, Private Garden, Private Gym, Private Jacuzzi, Private Pool, Security, Shared Gym, Shared Pool, Shared Spa, Study, View of Landmark, View of Water, Walk-in Closet, Concierge, Maid Service, Children's Play Area, Children's Pool, Barbecue Area, Lobby in Building, Reception/Waiting Room

---

### 6. COMPLIANCE CHECKLIST

Before outputting the final listing, validate against these rejection triggers:

- [ ] Title is 30-50 characters (English and Arabic)
- [ ] Description is 750-2,000 characters (English and Arabic)
- [ ] No contact details (phone, email, URL, WhatsApp) anywhere in title or description
- [ ] No pricing mentioned in title or description
- [ ] No agency/agent name in title or description
- [ ] Description does not contradict the listing data fields (beds, baths, size, type, location)
- [ ] No ALL CAPS words or sections
- [ ] No emojis or special characters in title
- [ ] Amenities are from the approved list only
- [ ] Arabic text is natural, not machine-translated
- [ ] Listing style matches the selected tone (Professional/Luxury/Investment)

---

## INPUT MAPPING

Map the ListingLaunch form fields to the Bayut/Profolio fields as follows:

| ListingLaunch Field | Bayut/Profolio Field |
|---|---|
| Property Type (Villa, Apartment, etc.) | Property Type |
| For Sale / For Rent | Purpose |
| Bedrooms | Bedrooms (0 = Studio) |
| Bathrooms | Bathrooms |
| Parking | Parking Spaces |
| Floor Number | Floor Number |
| Size (sqft) | Area (sqft) |
| Price (AED) | Price |
| Community | Location (Community) |
| Building / Tower Name | Building Name |
| Developer | Developer |
| Handover Date | Completion Date (off-plan only) |
| Key Features (checkboxes) | Amenities |
| Listing Style | (Determines description tone — not a portal field) |
| Additional Notes | (Used to inform description — not a portal field) |

**Additional fields the agent must fill in Profolio separately (not generated by ListingLaunch):**
- Trakheesi Permit Number
- Reference Number
- Photos (minimum 10, size 900x600px)
- Floor Plans
- Video URL (YouTube/Vimeo/Dailymotion)
- Agent assignment

---

## PHOTO GUIDANCE (include as a reminder in output)

Remind the agent:
- Minimum 10 high-quality photos required for verification eligibility
- Recommended resolution: 900x600px minimum
- Photos must be of the actual property (not stock images)
- No watermarks, agent logos, or text overlays on photos
- Order: exterior → living room → kitchen → bedrooms → bathrooms → views → amenities
- First photo is the cover image — make it the most compelling shot
