# Claude Code Prompt: Property Finder Listing Format Compliance

## Context

You are building the listing output for ListingLaunch (https://listing-launch-uae.netlify.app/new), a bilingual property listing tool for UAE real estate agents. When an agent fills in the property form and clicks "Generate Listing", the output must be fully compliant with Property Finder's listing requirements so the agent can paste it directly into PF Expert (Property Finder's listing management platform) with zero edits or rejections.

Property Finder has its own quality score system that directly impacts listing visibility and ranking. The output must be optimised to achieve 100% quality score.

---

## OUTPUT FORMAT

Generate a structured listing output with the following clearly labelled sections, ready for the agent to copy-paste field by field into PF Expert:

---

### 1. PROPERTY TITLE (English)

**Rules:**
- Maximum 40 characters (stricter than Bayut — this is the key difference)
- Must be short, precise, and highlight the listing's key differentiator
- Do NOT repeat information already visible in listing fields (beds, type, location, price)
- No emojis, no special characters, no excessive capitalisation
- No agent name, agency name, phone numbers, or URLs
- No pricing information

**Good examples:**
- "Full Sea View | High Floor | Vacant"
- "Upgraded | Private Pool | Corner Plot"
- "Brand New | Keys In Hand | Park View"
- "Tenanted | 7% Net ROI | Investor Deal"

**Bad examples:**
- "Beautiful 2BR Apt in Dubai Marina For Sale" (too long, repeats fields)
- "CALL NOW!! BEST DEAL!!" (caps, punctuation, no property info)
- "Apartment" (too vague, too short)

---

### 2. PROPERTY TITLE (Arabic)

**Rules:**
- Maximum 40 characters
- Natural Arabic — not machine-translated
- Convey the same selling point as English, adapted for Arabic audience
- Proper RTL text, no transliteration where Arabic terms exist

---

### 3. PROPERTY DESCRIPTION (English)

**Rules:**
- Minimum 1,000 characters for quality score (Property Finder values longer descriptions than Bayut)
- Maximum 2,000 characters
- Must NOT conflict with listing data fields
- Must NOT include contact details, pricing, agency info, or URLs
- Include details that data fields and photos cannot convey
- No ALL CAPS, no HTML, no special formatting
- Adapt tone to listing style (Professional / Luxury / Investment)

**Structure guide (optimised for PF quality score):**
1. **Hook** — one compelling sentence about the property's standout feature
2. **Property overview** — type, condition, layout summary (2 sentences)
3. **Interior detail** — room-by-room highlights, finishes, upgrades (3-4 sentences)
4. **Views and outdoor space** — balcony, garden, terrace, view type (1-2 sentences)
5. **Building/community amenities** — pool, gym, concierge, security (1-2 sentences)
6. **Location and lifestyle** — what's nearby (metro, mall, beach, schools), commute context (2 sentences)
7. **Closing** — availability, suitability (end-users, investors, families), call to action (1 sentence)

**Style variations:**
- **Professional:** Direct, factual, structured. Lead with value proposition. No fluff.
- **Luxury:** Elevated language, sensory details, lifestyle positioning. Emphasise exclusivity, design, prestige.
- **Investment:** Numbers-oriented where possible. Mention yield potential, tenant status, payment plans, capital appreciation drivers, handover timelines.

---

### 4. PROPERTY DESCRIPTION (Arabic)

**Rules:**
- Minimum 1,000 characters, maximum 2,000 characters
- Professionally written Arabic, not a literal translation
- Same structure and tone as English but naturally adapted
- Use UAE real estate Arabic terminology:
  - شقة (apartment), فيلا (villa), تاون هاوس (townhouse), بنتهاوس (penthouse)
  - غرف نوم (bedrooms), حمامات (bathrooms), مواقف سيارات (parking)
  - إطلالة بحرية (sea view), إطلالة على الحديقة (garden view)
  - مؤثثة بالكامل (fully furnished), شبه مؤثثة (semi-furnished)
  - جاهزة (ready), قيد الإنشاء (under construction)
  - عائد إيجاري (rental yield), خطة دفع (payment plan)

---

### 5. KEY FEATURES / AMENITIES

**Rules:**
- Property Finder uses a predefined list of amenities — custom values will NOT sync
- Only select amenities that genuinely apply to the property
- Map ListingLaunch features to PF-accepted values exactly

**Accepted Private Amenities (residential):**
- Balcony, Basement Parking, Built in Kitchen Appliances, Built in Wardrobes, Central A/C & Heating, Concierge Service, Covered Parking, Furnished, Kitchen Appliances, Lobby in Building, Maid's Room, Maids Room, Networked, On High Floor, On Low Floor, On Mid Floor, Pets Allowed, Private Garden, Private Gym, Private Jacuzzi, Private Pool, Private Sauna, Private Swimming Pool, Security, Shared Gym, Shared Pool, Shared Spa, Study, Unfurnished, Upgraded, Vacant, View of Landmark, View of Water, Walk-in Closet

**Accepted Commercial Amenities:**
- Available Furnished, Available Networked, Conference Room, Covered Parking, Dining in Building, Retail in Building, Shared Gym, Shared Pool, Shared Spa

---

### 6. LOCATION

**Rules:**
- Property Finder has a strict predefined location hierarchy: Country → City → Community → Sub-Community → Building
- Location text must match PF's location database exactly — misspellings or non-standard names cause rejections
- Use the official community name, not colloquial names (e.g. "Jumeirah Beach Residence" not "JBR" as the community — though JBR may be acceptable as a sub-community)
- If the building is not in PF's database, the agent will need to request it be added via PF support

**Map ListingLaunch communities to PF location hierarchy:**

| ListingLaunch | PF Community | PF City |
|---|---|---|
| Dubai Marina | Dubai Marina | Dubai |
| Downtown Dubai | Downtown Dubai | Dubai |
| Palm Jumeirah | Palm Jumeirah | Dubai |
| JVC | Jumeirah Village Circle (JVC) | Dubai |
| JBR | Jumeirah Beach Residence (JBR) | Dubai |
| DIFC | DIFC | Dubai |
| Business Bay | Business Bay | Dubai |
| Arabian Ranches | Arabian Ranches | Dubai |
| Meydan | Meydan City | Dubai |
| Jumeirah | Jumeirah | Dubai |
| Al Barsha | Al Barsha | Dubai |
| Dubai Hills | Dubai Hills Estate | Dubai |
| Creek Harbour | Dubai Creek Harbour | Dubai |
| Emaar Beachfront | Emaar Beachfront | Dubai |
| MBR City | Mohammed Bin Rashid City | Dubai |
| Dubai South | Dubai South | Dubai |
| Damac Hills | DAMAC Hills | Dubai |
| Town Square | Town Square | Dubai |
| Sobha Hartland | Sobha Hartland | Dubai |
| Al Furjan | Al Furjan | Dubai |
| Silicon Oasis | Dubai Silicon Oasis | Dubai |
| International City | International City | Dubai |
| Sports City | Dubai Sports City | Dubai |
| Motor City | Motor City | Dubai |
| JLT | Jumeirah Lake Towers (JLT) | Dubai |

---

### 7. PROPERTY TYPE MAPPING

**Property Finder uses specific property type codes. Map ListingLaunch types:**

| ListingLaunch | PF Property Type |
|---|---|
| Apartment | Apartment |
| Villa | Villa |
| Townhouse | Townhouse |
| Penthouse | Penthouse |
| Office | Office |
| Retail | Shop |
| Warehouse | Warehouse |

**Special cases:**
- If Bedrooms = 0 on Property Finder, it is mapped to "Studio" — ensure the description refers to it as a "studio" not "0 bedroom"
- For off-plan properties: set Completion Status to "Off-Plan" and include handover date

---

### 8. COMPLIANCE CHECKLIST (Property Finder Quality Score)

Before outputting the final listing, validate against PF's quality score criteria:

**Title (contributes to quality score):**
- [ ] Maximum 40 characters
- [ ] Describes key features, not generic
- [ ] No repetition of listing data fields
- [ ] No contact info, pricing, or agency name

**Description (contributes to quality score):**
- [ ] Minimum 1,000 characters (English and Arabic)
- [ ] Maximum 2,000 characters
- [ ] Provides information beyond what photos/fields show
- [ ] No contact details, pricing, URLs, or agency info
- [ ] No ALL CAPS or HTML formatting
- [ ] Does not contradict listing data fields

**Photos (reminder for agent):**
- [ ] Minimum 10 photos for quality score
- [ ] No duplicated images (PF's system detects this)
- [ ] Clear, well-lit, properly rotated
- [ ] Actual property photos, not stock or renders (unless off-plan)
- [ ] No watermarks or text overlays

**Amenities (contributes to quality score):**
- [ ] At least 5 amenities selected
- [ ] All amenities are from the PF-accepted list
- [ ] All amenities genuinely apply to the property

**Location (contributes to quality score):**
- [ ] Full location hierarchy provided (City → Community → Sub-Community → Building)
- [ ] Community name matches PF's location database exactly

**Permit:**
- [ ] Trakheesi permit number is valid and matches DLD records
- [ ] Permit is not expired
- [ ] Permit is not already used by 3+ brokers (sale) or 6+ brokers (rental)

---

## INPUT MAPPING

Map the ListingLaunch form fields to PF Expert fields:

| ListingLaunch Field | PF Expert Field |
|---|---|
| Property Type | Property Type |
| For Sale / For Rent | Purpose (Buy / Rent) |
| Bedrooms | Bedrooms (0 = Studio) |
| Bathrooms | Bathrooms |
| Parking | Parking |
| Floor Number | Floor |
| Size (sqft) | Size (sqft) |
| Price (AED) | Price (AED) |
| Community | Location (Community) |
| Building / Tower Name | Building / Tower |
| Developer | Developer |
| Handover Date | Handover (completion date) |
| Key Features | Amenities |
| Listing Style | (Tone control — not a PF field) |
| Additional Notes | (Informs description — not a PF field) |

**Fields the agent must fill in PF Expert separately:**
- Trakheesi Permit Number
- Reference Number
- Photos (minimum 10)
- Floor Plan images
- 360° Tour URL
- Video Tour URL
- Agent details (auto-populated from PF Expert profile)

---

## KEY DIFFERENCES FROM BAYUT (for dual-portal agents)

| Requirement | Bayut/dubizzle | Property Finder |
|---|---|---|
| Title max length | 50 characters | 40 characters |
| Description minimum | 750 characters | 1,000 characters |
| Description maximum | 2,000 characters | 2,000 characters |
| Photos minimum | 10 | 10 |
| Photo size | 900x600px | 900x600px recommended |
| Studio handling | Listed as "Studio" type | Bedrooms = 0 maps to Studio |
| Location names | Flexible matching | Strict predefined hierarchy |
| Amenity list | Bayut-specific terms | PF-specific terms (some overlap) |
| Verification | Checked + TruCheck badges | PF Verified badge |
| Quality scoring | Listing Quality Score (colour-coded) | Quality Score (percentage-based, 100% target) |
| Permit validation | Trakheesi via DLD API | Trakheesi via DLD API |
| Feed refresh | Periodic XML pull | Every 30 minutes |

---

## IMPORTANT NOTE FOR DUAL-PORTAL OUTPUT

If the agent wants output for BOTH Bayut and Property Finder from a single ListingLaunch submission:

1. Generate the **Property Finder version first** (stricter requirements)
2. The PF-compliant title (≤40 chars) will also work on Bayut (≤50 chars)
3. The PF-compliant description (≥1,000 chars) will also satisfy Bayut (≥750 chars)
4. Only the **amenity terms** and **location names** may need portal-specific mapping
5. Output both versions clearly labelled so the agent can paste the right one into each portal
